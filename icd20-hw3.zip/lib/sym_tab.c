#include <sym_tab.h>

int insertEntry(SymEntry** tab, char* id, VarType* type, int scope) {
    SHOW_NEWSYM(id);
    SymEntry *old = *tab;
    *tab = malloc(sizeof(SymEntry));
    (*tab)->id = id;
    (*tab)->type = type;
    (*tab)->scope = scope;
    (*tab)->next = old;
    return 0;
}

int deleteEntry(SymEntry** tab, int scope) {
    while(*tab != NULL && (*tab)->scope >= scope) {
        SymEntry *old = *tab;
        *tab = (*tab)->next;
        free(old);
    }
    return 0;
}

void getVarName(VarType* type, char* tgt) {
    if(type == NULL) {
        sprintf(tgt, "void");
        return;
    }
    switch(type->type) {
        case NONE:
            sprintf(tgt, "void");
            break;
        case VAR_ARRAY:
            sprintf(tgt, "[%d~%d]", type->begin->expression.val, type->end->expression.val);
            char tmp[128];
            getVarName(type->of_type, tmp);
            strcat(tmp, tgt);
            strcpy(tgt, tmp);
            break;
        case VAR_INT:
            sprintf(tgt, "int");
            break;
        case VAR_REAL:
            sprintf(tgt, "real");
            break;
        case VAR_TEXT:
            sprintf(tgt, "text");
            break;
        case VAR_FUNCTION:
            getVarName(type->ret_type, tgt);
            strcat(tgt, " (");
            for(Node *cur = type->args; cur != NULL; cur = cur->expression.next) {
                char type_tmp[32];
                getVarName(cur->declaration_node_attr.type, type_tmp);
                for(IDList *cur_l = cur->declaration_node_attr.list; cur_l != NULL; cur_l = cur_l->next) {
                    strcat(tgt, type_tmp);
                    if(cur_l->next != NULL) strcat(tgt, ", ");
                }
                if(cur->expression.next != NULL) strcat(tgt, ", ");
            }
            strcat(tgt, ")");
            break;
    }
}

void printSymTab(SymEntry *tab) {
    SHOW_SYMTAB_HEAD();
    for(SymEntry *cur = tab; cur != NULL; cur = cur->next) {
        char tmp[64];
        getVarName(cur->type, tmp);
        printf(SYMTAB_ENTRY_FMT , cur->id, cur->scope, tmp);
    }
    SHOW_SYMTAB_TAIL();
}

void traverseAST(Node* ast) {
    SymEntry *tab = NULL;
    _traverseAST(&tab, ast, 0, 0);
}

// method:
// 0: None
// 1: declaration
// 2: expr
VarType* _traverseAST(SymEntry** tab, Node* node, int scope, int method) {
    if(node == NULL) return NULL;
    switch((int)node->nt) {
        case ProgNode:{
            SHOW_NEWSCP();
            insertEntry(tab, node->prog_node_attr.id, node->prog_node_attr.ret_type, scope);
            _traverseAST(tab, node->prog_node_attr.args, scope, 1);
            _traverseAST(tab, node->prog_node_attr.declarations, scope, 1);
            _traverseAST(tab, node->prog_node_attr.subprogram_declarations, scope, 1);
            _traverseAST(tab, node->prog_node_attr.compound_statement, scope, 2);
            SHOW_CLSSCP();
            printSymTab(*tab);
            return node->prog_node_attr.ret_type;
        }
        case IDListNode:{
            /*for(IDList *cur = node->id_list; cur != NULL; cur = cur->next) {
                
            }*/
            return NULL;
        }
        case DeclarationNode:{
            for(struct Node *cur = node; cur != NULL; cur = cur->declaration_node_attr.next) {
                for(IDList *cur_l = cur->declaration_node_attr.list; cur_l != NULL; cur_l = cur_l->next) {
                    insertEntry(tab, cur_l->id, cur->declaration_node_attr.type, scope);
                }
            }
            return NULL;
        }
        case SubprogramDeclarationNode:{
            for(struct Node *cur = node; cur != NULL; cur = cur->subprogram_declaration_node_attr.next) {
                SHOW_NEWSCP();
                insertEntry(tab, cur->subprogram_declaration_node_attr.subprogram->prog_node_attr.id,
                    cur->subprogram_declaration_node_attr.subprogram->prog_node_attr.ret_type, scope);
                scope++;
                _traverseAST(tab, cur->subprogram_declaration_node_attr.subprogram->prog_node_attr.args, scope, 1);
                _traverseAST(tab, cur->subprogram_declaration_node_attr.subprogram->prog_node_attr.declarations, scope, 1);
                _traverseAST(tab, cur->subprogram_declaration_node_attr.subprogram->prog_node_attr.subprogram_declarations, scope, 1);
                _traverseAST(tab, cur->subprogram_declaration_node_attr.subprogram->prog_node_attr.compound_statement, scope, 2);
                SHOW_CLSSCP();
                printSymTab(*tab);
                deleteEntry(tab, scope);
                scope--;
            }
            return NULL;
        }
        case CompoundStatementListNode:{
            for(StmtList *stmt = node->compound_stmt_node_attr.stmts; stmt != NULL; stmt = stmt->next) {
                //printAST(stmt->stmt, level+1);
            }
            return NULL;
        }
        case ExprNode:{
            /*for(Node* cur = node; cur != NULL; cur = cur->expression.next) {
                switch(cur->expression.type) {
                    case Primary:
                        for(int i = 0; i < level; i++) printf("  ");
                        if(cur->expression.var_type == VAR_INT) {
                            printf("int: %d\n", cur->expression.val);
                        } else if(cur->expression.var_type == VAR_REAL) {
                            printf("real: %f\n", cur->expression.dval);
                        } else {
                            printf("text: %s\n", cur->expression.text);
                        }
                        break;
                    case Ref:
                        for(int i = 0; i < level; i++) printf("  ");
                        printf("var: %s\n", cur->expression.var_id);
                        break;
                    case Unary:
                        for(int i = 0; i < level; i++) printf("  ");
                        printf("%s\n", cur->expression.unary_op == OP_NOT ? "NOT" : "NEG");
                        printAST(cur->expression.oprand, level+1);
                        break;
                    case Binary:
                        for(int i = 0; i < level; i++) printf("  ");
                        printf("%s\n", op_mapping(cur->expression.binary_op));
                        printAST(cur->expression.left, level+1);
                        printAST(cur->expression.right, level+1);
                        break;
                    case Func:
                        for(int i = 0; i < level; i++) printf("  ");
                        printf("FUNC %s\n", cur->expression.id);
                        printAST(cur->expression.args, level+1);
                        break;
                }
            }*/
            return NULL;
        }
        case IfNode:/*
            for(int i = 0; i < level; i++) printf("  ");
            printf("IfNode\n");
            for(int i = 0; i < level; i++) printf("  ");
            printf("Condition\n");
            printAST(node->if_node_attr.condition, level+1);
            for(int i = 0; i < level; i++) printf("  ");
            printf("Statement\n");
            printAST(node->if_node_attr.statement, level+1);
            for(int i = 0; i < level; i++) printf("  ");
            printf("Else\n");
            printAST(node->if_node_attr.else_statement, level+1);*/
            return NULL;
        case WhileNode:/*
            for(int i = 0; i < level; i++) printf("  ");
            printf("WhileNode\n");
            for(int i = 0; i < level; i++) printf("  ");
            printf("Condition\n");
            printAST(node->while_node_attr.condition, level+1);
            for(int i = 0; i < level; i++) printf("  ");
            printf("Statement\n");
            printAST(node->while_node_attr.statement, level+1);*/
            return NULL;
    }
    return NULL;
}